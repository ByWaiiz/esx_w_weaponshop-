# Soon avalable
This feature is not yet implemented on NativeUILua-Reloaded.<p>

It will be added as soon as possible.<p>

**You have a suggestion? don't hesitate to suggest it, [read this article carefully beforehand](https://github.com/iTexZoz/NativeUILua-Reloaded/issues/9).**